# -*- coding: utf-8 -*-
from PyQt5 import QtWidgets             # Will used in the future.
from u_tools import UTools              # Import UTools class.


class UApp(QtWidgets.QWidget, UTools):  # Inheritance of the QWidgets
                                        # and UTools classes.
    def __init__(self, parent=None):    # Constructor of the UApp class.
        QtWidgets.QWidget.__init__(self, parent)  # Initialisation of
        UTools.__init__(self)           # QWidgets and UTools classes.
        self.start_qml()                # Starting of the function.

    def start_qml(self):                # That starts function from
        self.u_qml()                    # u_tools module to run QML.


if __name__ == "__main__":  # If name is not main - running as file
    import sys              # Standard library module
    app = QtWidgets.QApplication(sys.argv)  # Creating GUI app
    uap = UApp()            # Class instance.
    # uap.show()            # show application widget
    sys.exit(app.exec_())   # Application execution.
