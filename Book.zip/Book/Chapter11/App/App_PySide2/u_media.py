# -*- coding: utf-8 -*-
from PySide2 import QtMultimedia, QtMultimediaWidgets  # Multimedia classes.
from PySide2 import QtWidgets, QtCore, QtGui           # Icon, etc.
from u_style import UBut1                              # Button.


class UMedia(QtMultimediaWidgets.QCameraViewfinder):
    
    def __init__(self, parent=None):          # Constructor of the class.
        super(UMedia, self).__init__(parent)  # Initialization of the class.
        self.setWindowTitle("U Camera")       # Title of the application.
        win_icon = QtGui.QIcon("Icons/python1.png")         # QIcon path.
        self.setWindowIcon(win_icon)          # Set icon for this window.
        self.setWindowOpacity(1)              # Set widget opacity.
        self.camera = QtMultimedia.QCamera()  # Video Camera device.
        self.camera.setViewfinder(self)       # Set viewfinder for this
        self.camera.start()                   # camera and start.
        self.cambut1 = UBut1(self, pad=10)    # Button for capture image.
        self.cambut1.setText("Capture")       # Text of the button.
        self.cambut1.setVisible(False)        # Set visible false when 
        self.cambut1.clicked.connect(self.img_capture)  # window will open.
        self.vc_grid = QtWidgets.QGridLayout()          # Layout for this
        self.vc_grid.addWidget(self.cambut1, 0, 0, 1, 1)   # button that will
        self.vc_grid.setAlignment(QtCore.Qt.AlignTop)   # be at top position
        self.setLayout(self.vc_grid)          # Sets the layout to the widget.
    
    def img_capture(self):                    # Function for capture image
        image_capture = QtMultimedia.QCameraImageCapture(self.camera)
        image_capture.setCaptureDestination(  # Will call by click of the
                QtMultimedia.QCameraImageCapture.CaptureToFile)  # button
        self.camera.setCaptureMode(QtMultimedia.QCamera.CaptureStillImage)
        filename = os.path.abspath(__file__)     # Path to save image from
        camera_path = os.path.dirname(filename)  # the camera captures.
        image_capture.capture(r"%s\camera\captures" % camera_path)

    def enterEvent(self, event):              # When mouse pointer enter the
        self.cambut1.setVisible(True)         # widget, button will visible.
    
    def leaveEvent(self, event):              # When mouse pointer leave the
        self.cambut1.setVisible(False)        # widget, button will invisible.


if __name__ == "__main__":  # If file will run as application, name will main.
    import sys, os              # Import sys module from python stdlib.
    app = QtWidgets.QApplication(sys.argv)       # Create application.
    uap_vc = UMedia()       # Class instance of the application class.
    uap_vc.show()           # Show the widget when application start.
    sys.exit(app.exec_())   # Execute the application with return exit code.