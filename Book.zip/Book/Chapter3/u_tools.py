# -*- coding: utf-8 -*-
from PyQt5.QtCore import QUrl                  # Importing for url.
from PyQt5.QtQml import QQmlApplicationEngine  # QML engine.


class UTools():  # Class with tools for GUI application.

    def __init__(self):  # Constructor of the class.
        self.us1 = "Application with Python."  # Some string.

    def u_qml(self, parent=None):  # Function for running QML.
        self.qwid = QQmlApplicationEngine()  # QML engine
        self.qwid.load(QUrl('u_qml.qml'))    # infrastructure.


if __name__ == "__main__":  # If running as file - name is main.
    ut = UTools()           # Class instance.
