# -*- coding: utf-8 -*-      #   PYTHON 2   #
import pickle
import shelve
import csv
import os
# import pandas
import sqlite3

pathf = os.path.dirname(os.path.abspath(__file__))


class UTools(object):        # Class that will provide some functionality.
    
    def __init__(self):      # Constructor of the class.
        self.us1 = "Application with Python."           # String variable.
    
    def pickle_dump(self, obj=None, filename=None, proto=1, fimps=None):
        fobj = open(filename, 'wb')   # File object opened in binary mode.
        if fimps is not None:         # The fix_imports parameter, if not
            pickle.dump(obj, fobj, proto, fimps)  # None, and is True will be
        else:                # used to map the new Python3 names to the
            pickle.dump(obj, fobj)    # Python2 old module names, if None,
        fobj.close()         # used default or not used with Python2.

    def pickle_load(self, filename=None, fimps=None, enc="ASCII", err="strict"):
        fobj = open(filename, 'rb')   # Loads the file with data, if the 
        if fimps is not None:         # fix_imports is not None, will be used
            pl = pickle.load(fobj, fimps, encoding=enc, errors=err)
        else:                # parameters for Python3, if None, will be used
            pl = pickle.load(fobj)    # defaults for Python3 or will not be
        fobj.close()         # used for Python2 exclude file object in the
        return pl            # parameter. Returns loaded data from file.

    def shelve_open(self, filename=None, flag='c', proto=None, writeback=False):
        return shelve.open(filename, flag, proto, writeback)

    def csv_write(self, csvfile=None, fieldnames=None, mode='a', newline='',
                  rowdata=None, dialect=csv.excel, delimiter=' ', quotechar='|',
                  lineterminator='\r\n'):  # Function with parameters to append
        csvpath = os.path.exists(r"%s/%s" % (pathf, csvfile))
        try:                               # the data to the csv files with
            csvf = open(csvfile, mode)     # open the file in append mode.  
            csvw = csv.DictWriter(csvf, fieldnames=fieldnames, dialect=dialect,
                                  delimiter=delimiter, lineterminator=lineterminator)
            if csvpath is False:           # If path of the file to append with
                csvw.writeheader()         # dict writer is exists - add header.
            csvdict = {k: v for (k, v) in zip(fieldnames, rowdata)}
            csvw.writerow(csvdict)         # Writing row with dictionary where
        except Exception:                  # keys - fieldnames and values are
            pass                           # the data specified, error - pass.

    def csv_read(self, csvfile=None, mode='r', dialect=csv.excel,):
        try:                               # Function to read the csv files.
            csvf = open(csvfile, mode)     # Opens file object for reading.
            csvr = csv.DictReader(csvf, dialect=dialect, delimiter=' ')
            return csvr                    # Returns the csv dict reader object.
        except Exception:                  # If some error occurs with reading
            pass                           # of the csv file - pass.

    def pandas_write(self, filename=None, writer="csv", data=None,
                     columns=None, index=None, dtype=object):
        df = pandas.DataFrame(data, columns=columns, index=index, dtype=dtype)
        df.index.name = "rows\columns"     # Function to write the pandas
        if writer == "csv":                # csv, excel, etc., that specified 
            df.to_csv(filename)            # in the writer parameter. The If 
        if writer == "excel":              # statements checks the type of
            df.to_excel(filename)          # file to write with using pandas 
        if writer == "html":               # functions. The data is a dict
            df.to_html(filename)           # with specified keys - columns, 
        if writer == "json":               # values for this keys, indexes -
            df.to_json(filename)           # the number of rows. Returns
        return (df, writer)                # optionally data frame and writer.

    def pandas_read(self, filename=None, reader="csv", sep=',', delimiter=None,
                    engine='python', maxrows=999): # Function to read the 
        if reader == "csv":                # file specified with type of file
            df = pandas.read_csv(filename, engine=engine)  # with represent 
        if reader == "excel":              # to pandas dataframe that can be
            df = pandas.read_excel(filename)  # opened as csv file data, 
        if reader == "html":               # excel file data, html file data
            df = pandas.read_html(filename)   # with tags and used as html 
        if reader == "json":               # page, json representation etc.
            df = pandas.read_json(filename)   # Also, sets the options to 
        pandas.options.display.max_rows = maxrows  # display number of rows.
        return (df, reader)                # Returns data and reader that used.

    def sqlite_insert(self, username=None, email=None, passw=None, data=None):
        dbcon = sqlite3.connect("%s/data/u_db.sqlite" % pathf)  # Connect to
        dbcursor = dbcon.cursor()          # the database and open db cursor.
        sql_query = """INSERT INTO u_dbtable (user_name, user_email,
                        user_passw, user_data) VALUES (?, ?, ?, ?);"""
        try:                               # Executes the SQL query that
            udata = (str(username), str(email), str(passw), str(data))
            dbcursor.execute(sql_query, udata)      
            dbcon.commit()                 # specified in the first parameter
        except Exception:                  # as SQL text, and retreived data         
            pass                           # specified in the second parameter,
        dbcursor.close()                   # commit transaction then, if error 
        dbcon.close()                      # pass, closes cursor and database.

    def sqlite_select(self):
        dbcon = sqlite3.connect("%s/data/u_db.sqlite" % pathf)  # Connect to
        dbcursor = dbcon.cursor()          # the database and open db cursor.
        sql_query = """SELECT user_name, user_email, user_passw,
                        user_data FROM u_dbtable;"""
        dbcursor.execute(sql_query)        # Executes the SQL query that
        dbdata = dbcursor.fetchall()       # specified in the parameter as SQL
        dbcursor.close()                   # text, fetch all data selected,
        dbcon.close()                      # closes cursor and database.
        return dbdata                      # Returns fetched data.


    def sql_qt(self):
        # dbpath = "%s/data/sqldb" % os.path.dirname(__file__)
        sql_db = QtSql.QSqlDatabase()
        sql_db.addDatabase("QSQLITE", "connection1")
        sql_db.setDatabaseName("sqldb.db")
        sql_db.exec_()
        print sql_db.connectionName()
        print sql_db.databaseName()
        #query = QtSql.QSqlQuery("""CREATE TABLE IF NOT EXISTS user_info (indx INTEGER, user_name TEXT, user_email TEXT, user_passw TEXT, user_data TEXT);""")
        #query.exec_()


if __name__ == "__main__":   # Instruction when running as file.
    ut = UTools()            # Class instance, will run.
    ut.walks()
