# -*- coding: utf-8 -*-              #   PYTHON 2   #
from u_tools import UTools           # Importing of the class with functions.
from u_style import UWid, UFrame, ULabel      # Import of the styled widgets.
from u_style import ULineEd, UTextEd          # Import of the styled widgets.
from u_window import UWindow                  # Importing of the Main Window.
import enchant
from u_adds import UHighLight                


class UApp(UWindow, UTools):   # Create the main class of the application.
    
    def __init__(self, parent=None):        # Constructor of the class.
        super(UApp, self).__init__(parent)  # Initialisation of the class.
        UTools.__init__(self)               # Initialisation of the
        print self.us1                      # class with functions and print.
        self.frame1 = UFrame(self.twid3)    # Create the first frame with
        self.frame1.setLineWidth(3)         # parent as third widget.
        self.frame1.setFrameStyle(6)        # Styled panel frame style.
        self.text_edit = UTextEd(self.frame1)   # Text Edit field with 
        self.layfr1 = QtWidgets.QGridLayout()   # parent - the first frame.
        self.layfr1.addWidget(self.text_edit, 0, 0, 1, 1)     # And grid 
        self.frame1.setLayout(self.layfr1)      # layout for this field.
        self.frame2 = UFrame(self.twid3)    # Second with parent as 3d wid.
        self.frame2.setLineWidth(3)         # Sets line width of the frame
        self.frame2.setFrameStyle(0)        # and 0 - style No frame.
        self.frame2.setMaximumWidth(int(self.width()/3))        # Set width.  
        self.label1 = ULabel(self.frame2)   # Label will be in the second
        self.label1.setText("User Information")          # frame and this
        self.label1.setAlignment(QtCore.Qt.AlignCenter)  # will be a parent.
        self.line_ed1 = ULineEd(self.frame2)             # First line edit
        self.line_ed1.setPlaceholderText("Full Name...") # with placeholder.
        self.line_ed2 = ULineEd(self.frame2)             # Second that will
        self.line_ed2.setPlaceholderText("Email...")     # for user email.
        self.line_ed3 = ULineEd(self.frame2)             # Third field for
        self.line_ed3.setPlaceholderText("Password...")  # input password
        self.line_ed3.setEchoMode(QtWidgets.QLineEdit.Password) # echo mode.
        self.layfr2 = QtWidgets.QGridLayout()            # Adding to the
        self.layfr2.addWidget(self.label1, 0, 0, 1, 1)   # layout widgets,
        self.layfr2.addWidget(self.line_ed1, 1, 0, 1, 1) # first - name,
        self.layfr2.addWidget(self.line_ed2, 2, 0, 1, 1) # second - row.
        self.layfr2.addWidget(self.line_ed3, 3, 0, 1, 1) # third - column,
        self.frame2.setLayout(self.layfr2)               # 4/5 - rows/cols.
        self.lay1 = QtWidgets.QGridLayout()  # Layout for the third widget
        self.lay1.addWidget(self.frame1, 0, 0, 1, 1)  # of the tab widget
        self.lay1.addWidget(self.frame2, 0, 1, 1, 1)  # where frames will
        self.twid3.setLayout(self.lay1)      # be represented by grid.
        self.dicts = enchant.Dict("en_US")   # Set the dictionary.
        self.highlighter = UHighLight(self.text_edit.document())
        self.highlighter.setDict(self.dicts) # set dict to highlighter.


if __name__ == "__main__":  # If file will run as application name will main.
    import sys              # Import sys module from python stdlib.
    from PySide2 import QtWidgets, QtCore, QtGui  # PySide2 imports.
    app = QtWidgets.QApplication(sys.argv)  # Create application.
    uap = UApp()            # Class instance of the application class.
    uap.show()              # Show the widget when application start.
    sys.exit(app.exec_())   # Execute the application with return exit code.
