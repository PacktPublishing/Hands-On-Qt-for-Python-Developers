# -*- coding: utf-8 -*-                       #   PYTHON 2   #
from PySide2 import QtWidgets, QtCore, QtGui  # Import of the PySide2 modules.

color = ["rgba(0,41,59,140)", "rgba(0,41,59,255)"]  # Colors in RGBA format.


class UWid(QtWidgets.QWidget):              # Class for QWidget.

    def __init__(self, parent=None):        # Constructor of the class and
        super(UWid, self).__init__(parent)  # initialisation.
        self.setWindowTitle("U App")        # Title of the application
        self.setStyleSheet("background-color: %s;" % (color[0],))  # Styling.