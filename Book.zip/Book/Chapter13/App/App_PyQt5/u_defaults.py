# -*- coding: utf-8 -*-                  #   PYTHON 3   #
import os                                # Imports standard library os module.

def txt_file(state=False):
    colors = "rgba(0,41,59,140) rgba(0,41,59,255) rgba(1,255,217,140) rgba(1,255,217,255)"
    if os.path.exists("settings.txt") is state:   # If file is not exists,
        wstyle = open("settings.txt", "w")        # creates default file
        wstyle.write(colors)                      # writes the colors.
        wstyle.close()                            # Closes file object.
