# -*- coding: utf-8 -*-              #   PYTHON 3   #
from u_tools import UTools           # Importing of the class with functions.
from u_style import UWid, UFrame, ULabel      # Import of the styled widgets.
from u_style import ULineEd, UTextEd          # Import of the styled widgets.
from u_style import UComBox, UListV, UTabView # Import of the styled widgets.
from u_style import UBut1                     # Import of the styled widgets.
from u_style import UProgress                 # Import of the styled widgets.
from u_window import UWindow                  # Importing of the Main Window.
from u_table import UTModel                   # Import of the table model.


class UApp(UWindow, UTools):   # Create the main class of the application.

    def __init__(self, parent=None):        # Constructor of the class.
        super(UApp, self).__init__(parent)  # Initialization of the class.
        UTools.__init__(self)               # Initialization of the tools
        print(self.us1)                     # class with functions and print.
        self.frame1 = UFrame(self.twid3)    # Create the first frame with
        self.frame1.setLineWidth(3)         # parent as third widget.
        self.frame1.setFrameStyle(6)        # Styled panel frame style.
        self.table = UTabView(self.frame1)  # Creation of the table with
        self.table.setVisible(False)        # parent as frame 1 and gets
        model = UTModel()                   # data from the model. Unvisible.
        self.table.setModel(model)          # Set model data to the table.
        self.text_edit = UTextEd(self.frame1)   # Text Edit field with 
        self.layfr1 = QtWidgets.QGridLayout()   # parent - the first frame.
        self.layfr1.addWidget(self.table, 0, 0, 1, 1)         # Add table.
        self.layfr1.addWidget(self.text_edit, 0, 0, 1, 1)     # And grid 
        self.frame1.setLayout(self.layfr1)      # layout for this field.
        self.frame2 = UFrame(self.twid3)    # Second with parent as 3d wid.
        self.frame2.setLineWidth(3)         # Sets line width of the frame
        self.frame2.setFrameStyle(0)        # and 0 - style No frame.
        self.frame2.setMaximumWidth(int(self.width()/3))        # Set width.
        self.label1 = ULabel(self.frame2)   # Label will be in the second
        self.label1.setText("User Information")          # frame and this
        self.label1.setAlignment(QtCore.Qt.AlignCenter)  # will be a parent.
        self.combox1 = UComBox(self.frame2)              # Add the combo box.
        self.combox1.addItems(["Texts", "Table"])        # Combo box items.
        self.combox1.setView(UListV())                   # Combo popup view.
        self.line_ed1 = ULineEd(self.frame2)             # First line edit
        self.line_ed1.setPlaceholderText("Full Name...") # with placeholder.
        self.line_ed2 = ULineEd(self.frame2)             # Second that will
        self.line_ed2.setPlaceholderText("Email...")     # for user email.
        self.line_ed3 = ULineEd(self.frame2)             # Third field for
        self.line_ed3.setPlaceholderText("Password...")  # input password
        self.line_ed3.setEchoMode(2)                     # with echo mode.
        self.push_but1 = UBut1(self.frame2)              # Adding of the
        self.push_but1.setText("Ok")                     # button with text.
        self.progress1 = UProgress(self.frame2)          # Adding progress
        self.progress1.setRange(0, 0)                    # bar with range.
        self.layfr2_1 = QtWidgets.QGridLayout()          # Layout for this
        self.layfr2_1.addWidget(self.push_but1, 0, 1, 1, 1)  # Button and
        self.layfr2_1.addWidget(self.progress1, 1, 0, 1, 2)  # Progress Bar.
        self.layfr2 = QtWidgets.QGridLayout()            # Layout for the 
        self.layfr2.addWidget(self.combox1, 0, 0, 1, 1)  # second frame with
        self.layfr2.addWidget(self.label1, 1, 0, 1, 1)   # components such as
        self.layfr2.addWidget(self.line_ed1, 2, 0, 1, 1) # combo box, label
        self.layfr2.addWidget(self.line_ed2, 3, 0, 1, 1) # line edits, and 
        self.layfr2.addWidget(self.line_ed3, 4, 0, 1, 1) # layout with button.
        self.layfr2.addLayout(self.layfr2_1, 5, 0, 1, 1) # The components will
        self.frame2.setLayout(self.layfr2)               # be added to frame.
        self.lay1 = QtWidgets.QGridLayout()  # Layout for the third widget
        self.lay1.addWidget(self.frame1, 0, 0, 1, 1)  # of the tab widget
        self.lay1.addWidget(self.frame2, 0, 1, 1, 1)  # where frames will
        self.twid3.setLayout(self.lay1)      # be represented by grid.
        self.combox1.activated.connect(self.txt_table)  # Combo box Signal. 

    def txt_table(self):                           # The function that will
        if self.combox1.currentText() == "Texts":  # visualize the table and
            self.text_edit.setVisible(True)        # text field depends on
            self.table.setVisible(False)           # text of the combo box,
        if self.combox1.currentText() == "Table":  # that user will choose. 
            self.text_edit.setVisible(False)       # When the text activated,
            self.table.setVisible(True)            # elements visible or not.


if __name__ == "__main__":  # If file will run as application, name will main.
    import sys              # Import sys module from python stdlib.
    from PyQt5 import QtWidgets, QtCore, QtGui  # PyQt5 imports.
    app = QtWidgets.QApplication(sys.argv)  # Create application.
    uap = UApp()            # Class instance of the application class.
    uap.show()              # Show the widget when application start.
    sys.exit(app.exec_())   # Execute the application with return exit code.
