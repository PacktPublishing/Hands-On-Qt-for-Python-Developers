# -*- coding: utf-8 -*-
from PySide2 import QtWidgets, QtCore, QtGui


class ULayout(QtWidgets.QLayout):

    def __init__(self, parent=None):      # Constructor of the ULayout class.
        super(ULayout, self).__init__(parent)               # Initialization.
        self.setSpacing(10)
        print self.getContentsMargins()


class ULayoutItem(QtWidgets.QLayoutItem):

    def __init__(self, parent=None):      # Constructor of the ULayout class.
        super(ULayoutItem, self).__init__(parent)           # Initialization.