# -*- coding: utf-8 -*-                  #   PYTHON 3   #
import os                                # Imports standard library os module.
import sqlite3                           # Importing for the SQLite database.


def txt_file(state=False):
    colors = "rgba(0,41,59,140) rgba(0,41,59,255) rgba(1,255,217,140) rgba(1,255,217,255)"
    if os.path.exists("settings.txt") is state:   # If file is not exists,
        wstyle = open("settings.txt", "w")        # creates default file
        wstyle.write(colors)                      # writes the colors.
        wstyle.close()                            # Closes file object.


dbpath = os.path.dirname(os.path.abspath(__file__))  # Path to the database.

dbcon = sqlite3.connect("%s/data/u_db.sqlite" % dbpath)  # Create if not exists
dbcursor = dbcon.cursor()                # or connect to database with path.
sql_query = """CREATE TABLE IF NOT EXISTS u_dbtable (
                info_date DEFAULT CURRENT_TIMESTAMP, user_name TEXT UNIQUE,
                user_email TEXT UNIQUE, user_passw TEXT, user_data TEXT UNIQUE);"""
dbcursor.execute(sql_query)              # Executes the SQL query that 
dbcursor.close()                         # specified in the parameter as SQL
dbcon.close()                            # text, closes cursor and database.
