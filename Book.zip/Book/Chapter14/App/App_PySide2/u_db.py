# -*- coding: utf-8 -*
# import sys
import os
from PySide2 import QtCore, QtSql


app = QtCore.QCoreApplication([])
dbpath = app.applicationDirPath() + "\data\db.sqlite"
sql_path = os.path.abspath(os.path.dirname(__file__)) + "\data\db.sqlite"
sql_db = QtSql.QSqlDatabase()
sql_db.addDatabase("QSQLITE", "DataBase")
sql_db.setDatabaseName("sqldb1.sqlite")
print sql_db.drivers()
print dbpath
app.exec_()
