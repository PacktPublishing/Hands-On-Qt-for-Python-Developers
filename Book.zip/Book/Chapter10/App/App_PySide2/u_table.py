# -*- coding: utf-8 -*-
from PySide2 import QtCore             # Importing of the abstract models.
import random                          # Python stdlib module.


class UIModel(QtCore.QAbstractItemModel):
    
    def __init__(self, parent=None):
        super(UIModel, self).__init__(parent)

    def rowCount(self, parent):
        return 50

    def columnCount(self, parent):
        return 10
    
    def index(self, row, column, parent):
        return parent
    
    def data(self, index, role):
        return 1


class UTModel(QtCore.QAbstractTableModel):     # Class for the model.

    def __init__(self, parent=None):           # Constructor for this class.
        super(UTModel, self).__init__(parent)  # Initialization of the class.

    def rowCount(self, parent):                # Function that will return
        return 27                              # the number of the rows.

    def columnCount(self, parent):             # Function that will return
        return 14                              # the number of the columns.

    def data(self, row, column):               # Function that will return
        randn = random.randint(1, 100)         # the data for this model as
        return randn                           # random numbers for items.