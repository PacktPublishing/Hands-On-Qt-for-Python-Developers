# -*- coding: utf-8 -*-     #   PYTHON 3   #
from u_tools import UTools  # Importing of the class with functions.
from u_style import UWid    # Import styling for the application.

class UApp(UWid, UTools):   # Create the main class of the application.
    
    def __init__(self, parent=None):        # Constructor of the class.
        super(UApp, self).__init__(parent)  # Initialisation of the class.
        UTools.__init__(self)               # Initialisation of the
        print(self.us1)                     # class with functions and print.


if __name__ == "__main__":  # If file will run as application name will main.
    import sys              # Import sys module from python stdlib.
    from PyQt5 import QtWidgets, QtCore, QtGui  # PyQt5 imports.
    app = QtWidgets.QApplication(sys.argv)  # Create application.
    uap = UApp()            # Class instance of the application class.
    uap.show()              # Show the widget when application start.
    print("sys module list of arguments: ", sys.argv)
    print("      qApp list of arguments: ", QtWidgets.qApp.arguments())
    print("      Application Process ID: ", QtWidgets.qApp.applicationPid())
    print("        Application instance: ", QtWidgets.qApp.instance())
    print("           Application state: ", QtWidgets.qApp.applicationState())
    print("        Application platform: ", QtWidgets.qApp.platformName())
    print("         List of the widgets: ", QtWidgets.qApp.allWidgets())
    sys.exit(app.exec_())   # Execute the application with return exit code.
