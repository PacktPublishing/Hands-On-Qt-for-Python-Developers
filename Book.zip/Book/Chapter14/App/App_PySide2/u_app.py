# -*- coding: utf-8 -*-              #   PYTHON 2   #
import u_defaults                    # Setting of the default values, colors,
u_defaults.txt_file(state=False)     # etc. to the application settings.
from u_tools import UTools           # Importing of the class with functions.
from u_style import UWid, UFrame, ULabel      # Import of the styled widgets.
from u_style import ULineEd, UTextEd          # Import of the styled widgets.
from u_style import UComBox, UListV, UTabView # Import of the styled widgets.
from u_style import UBut1                     # Import of the styled widgets.
from u_style import UProgress                 # Import of the styled widgets.
from u_window import UWindow                  # Importing of the Main Window.               
from u_table import UTModel                   # Import of the table model.
from PySide2 import QtPrintSupport            # Importing for the printer.


class UApp(UWindow, UTools):   # Create the main class of the application.
    
    def __init__(self, parent=None):        # Constructor of the UApp class.
        super(UApp, self).__init__(parent)  # Initialization of the class.
        UTools.__init__(self)               # Initialization of the tools
        print self.us1                      # class with functions and print.
        self.frame1 = UFrame(self.twid3)    # Create the first frame with
        self.frame1.setLineWidth(3)         # parent as third widget.
        self.frame1.setFrameStyle(6)        # Styled panel frame style.
        self.table = UTabView(self.frame1)  # Creation of the table with
        self.table.setVisible(False)        # parent as frame 1 and gets
        model = UTModel()                   # data from the model. Unvisible.
        self.table.setModel(model)          # Set model data to the table.
        self.text_edit = UTextEd(self.frame1)   # Text Edit field with 
        self.layfr1 = QtWidgets.QGridLayout()   # parent - the first frame.
        self.layfr1.addWidget(self.table, 0, 0, 1, 1)     # Add table widget.
        self.layfr1.addWidget(self.text_edit, 0, 0, 1, 1) # Add text field.
        self.layfr1.setContentsMargins(0, 0, 0, 0)     # Space around layout.   
        self.frame1.setLayout(self.layfr1)      # layout for this field.
        self.frame2 = UFrame(self.twid3)    # Second with parent as 3d wid.
        self.frame2.setLineWidth(3)         # Sets line width of the frame
        self.frame2.setFrameStyle(0)        # and 0 - style No frame.
        self.frame2.setMaximumWidth(int(self.width()/3))        # Set width.
        self.label1 = ULabel(self.frame2)   # Label will be in the second
        self.label1.setText("User Information")          # frame and this
        self.label1.setAlignment(QtCore.Qt.AlignCenter)  # will be a parent.
        self.combox1 = UComBox(self.frame2)              # Add the combo box.
        self.combox1.addItems(["Texts", "Table"])        # Combo box items.
        self.combox1.setView(UListV())                   # Combo popup view.
        self.line_ed1 = ULineEd(self.frame2)             # First line edit
        self.line_ed1.setPlaceholderText("Full Name...") # with placeholder.
        self.line_ed2 = ULineEd(self.frame2)             # Second that will
        self.line_ed2.setPlaceholderText("Email...")     # for user email.
        self.line_ed3 = ULineEd(self.frame2)             # Third field for
        self.line_ed3.setPlaceholderText("Password...")  # input password,
        self.line_ed3.setEchoMode(QtWidgets.QLineEdit.Password) # echo mode.
        self.push_but1 = UBut1(self.frame2)              # Adding of the
        self.push_but1.setText("Ok")                     # button with text.
        self.progress1 = UProgress(self.frame2)          # Adding progress
        self.progress1.setRange(0, 0)                    # bar with range.
        self.layfr2_1 = QtWidgets.QGridLayout()          # Layout for this
        self.layfr2_1.addWidget(self.push_but1, 0, 1, 1, 1)  # Button and
        self.layfr2_1.addWidget(self.progress1, 1, 0, 1, 2)  # Progress Bar.
        self.layfr2_1.setSpacing(3)                      # Widgets spacing.
        self.layfr2 = QtWidgets.QGridLayout()            # Layout for the 
        self.layfr2.addWidget(self.combox1, 0, 0, 1, 1)  # second frame with
        self.layfr2.addWidget(self.label1, 1, 0, 1, 1)   # components such as
        self.layfr2.addWidget(self.line_ed1, 2, 0, 1, 1) # combo box, label
        self.layfr2.addWidget(self.line_ed2, 3, 0, 1, 1) # line edits, and 
        self.layfr2.addWidget(self.line_ed3, 4, 0, 1, 1) # layout with button
        self.layfr2.addLayout(self.layfr2_1, 5, 0, 1, 1) # and progress bar.
        self.layfr2.setSpacing(3)                        # Spacing between
        self.layfr2.setContentsMargins(3, 3, 3, 3)    # widgets and arround.
        self.frame2.setLayout(self.layfr2)            # Set layout to frame.
        self.lay1 = QtWidgets.QGridLayout()  # Layout for the third widget
        self.lay1.addWidget(self.frame1, 0, 0, 1, 1)  # of the tab widget
        self.lay1.addWidget(self.frame2, 0, 1, 1, 1)  # where frames will
        self.twid3.setLayout(self.lay1)      # be represented by grid.
        self.combox1.activated.connect(self.txt_table)  # Combo box Signal.
        # self.video_camera()                  # Run video camera function.
        self.mb1.triggered.connect(self.files) # Calling files function.
        self.mb3.triggered.connect(self.options)   # Calling files function.
        self.print_device = QtPrintSupport.QPrinter()  # Adding of the Printer.
        self.push_but1.clicked.connect(self.user_data5) # Calling of the data.

    def txt_table(self):                           # The function that will
        if self.combox1.currentText() == "Texts":  # visualize the table and
            self.text_edit.setVisible(True)        # text field depends on
            self.table.setVisible(False)           # text of the combo box,
        if self.combox1.currentText() == "Table":  # that user will choose. 
            self.text_edit.setVisible(False)       # When the text activated,
            self.table.setVisible(True)            # elements visible or not.

    def video_camera(self):                    # Function to run video camera.
        subprocess.Popen(["python", r"u_media.py"])  # Subprocess in the app.

    def files(self, action):                   # Function for open/save files.
        fd = QtWidgets.QFileDialog()           # File dialog instance.
        if action.text() == "Open":            # For opening of the files.
            fdf = fd.getOpenFileNames(self, caption="Open Files",
                                      directory=QtCore.QDir.homePath())
            if len(fdf[0]) > 0:                # Checks if the file dialog
                self.text_edit.clear()         # has a selected files for
                for of in fdf[0]:              # open. Each file of the
                    self.tabwid.setCurrentIndex(2)  # selected will be open. 
                    try:                       # Will try to open file as
                        openf = open(of, 'r')  # simple .txt or .html and 
                        self.text_edit.append(str(openf.read()))  # append
                        continue               # read content to text field.
                    except Exception:          # If successfull continue loop.
                        pass                   # If unread or error - pass.
                    try:                       # Try to open file in the 
                        openf = open(of, 'rb') # binary mode .py or other.
                        self.text_edit.append(str(openf.read()))  # Append
                    except Exception:          # content to the field, if 
                        pass                   # error - pass (do nothing).
        if action.text() == "Save":            # For saving of the files.
            fdf = fd.getSaveFileName(self, caption="Save Files",
                                     directory=QtCore.QDir.homePath())
            if fdf[0] != "":                   # Checks if files selected.
                self.tabwid.setCurrentIndex(2) # Open TabWid with Text Field.
                try:                           # Will try to save file as
                    open(fdf[0], 'w').write(self.text_edit.toPlainText())
                    success = True             # .txt file with plain text of
                except Exception:              # text field. And success is 
                    pass                       # True. An error - pass.
                if success != True:            # If file was not saved as .txt           
                    try:                       # will try to save file in the
                        open(fdf[0], 'wb').write(self.text_edit.toPlainText())
                        success = True         # binary mode, with plain text.
                    except Exception:          # An exxeption - will pass.
                        pass                   # If success is True will 
                if success == True:            # shown information message.
                    self.info_message(fpath=fdf[0], txt="File saved as",
                                      types="info")      # Parameters passed.
                else:                          # If is not True, will be
                    self.info_message(fpath=fdf[0], txt="File don`t saved",
                                      types="critical")  # critical message.
        if action.text() == "Print":
            print_dialog = QtPrintSupport.QPrintDialog(self.print_device)
            if print_dialog.exec_() == QtWidgets.QDialog.Accepted:
                self.text_edit.print_(print_dialog.printer())
        if action.text() == "Print Preview":
            print_dialog = QtPrintSupport.QPrintPreviewDialog(self.print_device)
            print_dialog.setWindowTitle("Print Preview")
            print_dialog.setWindowIcon(QtGui.QIcon("Icons/python1.png"))
            print_dialog.paintRequested.connect(self.text_edit.print_)
            print_dialog.exec_()

    def options(self, action):             # Function to run tools by
        if action.text() == "Settings":     # selectection options items.
            from u_settings import USets    # Importing class for color
            self.sets = USets()             # settings, class instance.
            self.sets.show()                # Shows widget for color settings.
            self.sets.bsave.clicked.connect(self.sets_but)      # Save clicks.
            self.sets.breset.clicked.connect(self.to_default)   # Restores.

    def sets_but(self):                     # Function for the "Save" clicks.
        colors = "%s %s %s %s" % (self.sets.bgle1.text(), self.sets.bgle2.text(),
                                  self.sets.colle1.text(), self.sets.colle2.text())
        save_open = open("settings.txt", "w")  # Opens settings.txt file and
        save_open.write(colors)              # writes the colors from line
        save_open.close()                    # edit field, then closes.
        self.new_app()                       # Call the function for new.
    
    def to_default(self):                    # Function to restore the
        u_defaults.txt_file(state=True)      # default colors and calling
        self.new_app()                       # new app in the subprocess.
    
    def new_app(self):                       # Function to re-open new app.
        self.sets.hide()                     # Hides the widget (optional).
        subprocess.Popen(["python", r"u_app.py"])  # Run application and exit
        sys.exit(0)                          # old app (can be used optional).

    def info_message(self, fpath='', txt='', types="info"):  # Function with
        message_box = QtWidgets.QMessageBox(self)            # message box.
        message_box.setStyleSheet("color: #FFFFFF;")         # Color for text
        message_box.setFont(QtGui.QFont("Verdana", 12, 77))  # and font, can
        message_box.setWindowTitle("Save files")             # be added other.
        if types == "info":                                  # Icons for this
            message_box.setIcon(QtWidgets.QMessageBox.Information)
        if types == "critical":                              # message box.
            message_box.setIcon(QtWidgets.QMessageBox.Critical) 
        message_box.addButton(QtWidgets.QMessageBox.Ok)      # Adding button.
        message_txt = "%s\n%s" %(txt, fpath)                 # Text that will
        message_box.setText(message_txt)                     # shown with box.
        message_box.exec_()                                  # Show the box.

    def user_data1(self):              # Function for the user data available.
        udata = {"User Name": self.line_ed1.text(),
                  "User email": self.line_ed2.text(),
                  "User password": self.line_ed3.text(),
                  "User data": self.text_edit.toPlainText()}  # Data as dict.
        self.pickle_dump(obj=udata, filename=r"data/u_data.py")  # Data to file.
        txtdata = self.pickle_load(filename=r"data/u_data.py")   # Data from file.
        self.text_edit.setText(str(txtdata))  # Data to the text edit field.

    def user_data2(self):              # Function for the user data available.
        db = self.shelve_open(filename="data/u_data")    # Opens db file.
        db["User Name"] = self.line_ed1.text()           # Saves with keys
        db["User email"] = self.line_ed2.text()          # the name, email,
        db["User password"] = self.line_ed3.text()       # password, and 
        db["User data"] = self.text_edit.toPlainText()   # data of this user.
        self.text_edit.setText(                          # Sets values of the
                "%s\n%s\n%s\n%s" % (db.get("User Name"), db.get("User email"),
                                    db.get("User password"), db.get("User data")))
        db.close()                    # database to the text field and closes db.

    def user_data3(self):             # Writes and reads the csv files.
        fnames = ["User_Name", "User_email", "User_password", "User_data"]
        rdata = [self.line_ed1.text(), self.line_ed2.text(),
                 self.line_ed3.text(), self.text_edit.toPlainText()[:140]]
        if (rdata == ['', '', '', '']) or (rdata[0] == '') or (rdata[2] == ''):
            rdata = None              # If fields is empty data will be None.
        try:                          # Check if the user with name and passsword 
            for row in self.csv_read(csvfile="data/tests.csv"):
                if (row["User_Name"] == rdata[0]) and (row["User_password"] == rdata[2]):
                    rdata = None      # is exists in this csv file, if True
        except Exception:             # data will be None and will not be
            pass                      # added to the csv file, if erorr - pass. 
        if rdata is not None:         # If data is not None, will be added.
            self.csv_write(csvfile="data/tests.csv", fieldnames=fnames,
                           rowdata=rdata, delimiter=' ', lineterminator='\n')
            self.text_edit.clear()        # Clears the text edit field.
            for row in self.csv_read(csvfile="data/tests.csv"):           
                self.text_edit.append(    # Reads the csv object and append.
                        "%s %s %s %s" % (row["User_Name"], row["User_email"],
                                         row["User_password"], row["User_data"]))

    def user_data4(self):             # Writes and reads the csv files with pandas.
        ucolumns = ["User_Name", "User_email", "User_password", "User_data"]
        uindex = [i for i in range(1000)]      # number of rows is 999.
        udata = {"User_Name": range(0, 1000), "User_email": range(0, 1000),
                 "User_password": range(0, 1000), "User_data": range(0, 1000)}
        self.pandas_write(filename="data/tests.csv", writer="csv",
                          data=udata, columns=ucolumns, index=uindex)
        pread = self.pandas_read(filename="data/tests.csv", reader="csv",
                                 sep=',')      # Reads the data and set the 
        self.text_edit.setText(str(pread[0]))  # text to the text edit field.

    def user_data5(self):             # Function starts the sqlite database.
        uname, umail = self.line_ed1.text(), self.line_ed2.text()  
        upass, udata = self.line_ed3.text(), self.text_edit.toPlainText()
        if (uname != '') and (umail != '') and (upass != ''):  # Insertion.
            self.sqlite_insert(username=uname, email=umail, passw=upass, data=udata)
        dbdata = self.sqlite_select()          # Selection from database and
        for dtx in dbdata:                     # set text to the text field.
            self.text_edit.setText("%s\n%s\n%s\n%s\n%s" % (dtx[0], dtx[1], dtx[2],
                                                           dtx[3], dtx[4]))


if __name__ == "__main__":  # If file will run as application, name will main.
    import sys, subprocess  # Import modules from python stdlib.
    from PySide2 import QtWidgets, QtCore, QtGui  # PySide2 imports.
    app = QtWidgets.QApplication(sys.argv)  # Create application.
    uap = UApp()            # Class instance of the application class.
    uap.show()              # Show the widget when application start.
    sys.exit(app.exec_())   # Execute the application with return exit code.
