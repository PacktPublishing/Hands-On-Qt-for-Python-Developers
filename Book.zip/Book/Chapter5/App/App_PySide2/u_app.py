# -*- coding: utf-8 -*-     #   PYTHON 2   #
from u_tools import UTools    # Importing of the class with functions.
from u_style import UWid      # Import styling for the application.
from u_window import UWindow  # Importing of the Main Window.                


class UApp(UWindow, UTools):   # Create the main class of the application.
    
    def __init__(self, parent=None):        # Constructor of the class.
        super(UApp, self).__init__(parent)  # Initialisation of the class.
        UTools.__init__(self)               # Initialisation of the
        print self.us1                      # class with functions and print.


if __name__ == "__main__":  # If file will run as application name will main.
    import sys              # Import sys module from python stdlib.
    from PySide2 import QtWidgets, QtCore, QtGui  # PySide2 imports.
    app = QtWidgets.QApplication(sys.argv)  # Create application.
    uap = UApp()            # Class instance of the application class.
    uap.show()              # Show the widget when application start.
    sys.exit(app.exec_())   # Execute the application with return exit code.
