# -*- coding: utf-8 -*-
from PyQt5.QtCore import QUrl
from PyQt5.QtQml import QQmlApplicationEngine
from PyQt5 import QtWidgets


class UQml(QtWidgets.QWidget):

    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.start_qml()

    def start_qml(self):
        qwid = QQmlApplicationEngine()
        qwid.load(QUrl('u_qml.qml'))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    qwin = UQml()
    qwin.show()
    sys.exit()
    app.exec_()
