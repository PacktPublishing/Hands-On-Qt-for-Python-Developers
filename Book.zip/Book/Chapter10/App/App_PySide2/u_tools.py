# -*- coding: utf-8 -*-     #   PYTHON 2   #
class UTools(object):       # Class that will provide some functionality.

    def __init__(self):     # Constructor of the class.
        self.us1 = "Application with Python."   # String variable.


if __name__ == "__main__":  # Instruction when running as file.
    ut = UTools()           # Class instance, will run.
