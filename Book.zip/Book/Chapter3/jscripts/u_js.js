function RZfunc(width) { // Javascript function receive parameter width
    for (i=0; i=width; i++) {
        return i;       // function return
    };
}